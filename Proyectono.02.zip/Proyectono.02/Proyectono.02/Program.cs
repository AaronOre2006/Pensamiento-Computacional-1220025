﻿using System;
using System.Threading;

class ProgramaEstacionamiento
{
    static void Main()
    {
        // Solicitar datos iniciales de configuración del estacionamiento
       int cant_Estacionamientos;
while (true)
{
    Console.WriteLine("Ingrese la cantidad de estacionamientos por piso:");
    if (int.TryParse(Console.ReadLine(), out cant_Estacionamientos))
        break;
    Console.WriteLine("Entrada inválida. Por favor, ingrese un número entero.");
}

int cant_Pisos;
while (true)
{
    Console.WriteLine("Ingrese la cantidad de pisos habilitados al público:");
    if (int.TryParse(Console.ReadLine(), out cant_Pisos))
        break;
    Console.WriteLine("Entrada inválida. Por favor, ingrese un número entero.");
}

int cant_Moto;
while (true)
{
    Console.WriteLine("Ingrese la cantidad de vehículos tipo moto:");
    if (int.TryParse(Console.ReadLine(), out cant_Moto))
        break;
    Console.WriteLine("Entrada inválida. Por favor, ingrese un número entero.");
}

int cant_SUV;
while (true)
{
    Console.WriteLine("Ingrese la cantidad de vehículos tipo SUV:");
    if (int.TryParse(Console.ReadLine(), out cant_SUV))
        break;
    Console.WriteLine("Entrada inválida. Por favor, ingrese un número entero.");
}


        // Calcular total de espacios y cantidad de sedanes
        int total_Estacionamientos = cant_Estacionamientos * cant_Pisos;
        int cant_Sedan = total_Estacionamientos - (cant_Moto + cant_SUV);

        // Crear matriz para representar el estacionamiento
        string[,] matriz_Estacionamiento = new string[cant_Pisos, cant_Estacionamientos];
        int contador = 0;

        // Inicializar matriz con tipos de vehículos permitidos en cada espacio
        for (int i = 0; i < cant_Pisos; i++)
        {
            for (int j = 0; j < cant_Estacionamientos; j++)
            {
                if (contador < cant_Moto)
                    matriz_Estacionamiento[i, j] = "moto";
                else if (contador < cant_Moto + cant_SUV)
                    matriz_Estacionamiento[i, j] = "suv";
                else
                    matriz_Estacionamiento[i, j] = "sedan";

                contador = contador+1;
            }
        }

        // Variables para el menú principal
        bool respuesta;
        string placa_Vehi = "";
        string codigo_Parqueo;
        bool monto_Valido = false;
        int vuelto;

        // Bucle principal del programa
        do
        {
            respuesta = false;

            int opcion;
            do
            {
                // Mostrar menú de opciones
                Console.WriteLine("\nElige una opción:");
                Console.WriteLine("1. Ingresar un vehículo manualmente");
                Console.WriteLine("2. Ingresar lote de vehículos");
                Console.WriteLine("3. Encontrar un vehículo");
                Console.WriteLine("4. Retirar un vehículo");
                Console.WriteLine("5. Salir");

                while (!int.TryParse(Console.ReadLine(), out opcion))
                {
                    Console.WriteLine("¡Error! Opción no válida");
                }

                // Mostrar mensaje según opción seleccionada
                Console.WriteLine(opcion switch
                {
                    1 => "Cargando...",
                    2 => "Cargando...",
                    3 => "Cargando...",
                    4 => "Cargando...",
                    5 => "Saliendo...",
                    _ => "Acción no válida"
                });

                Thread.Sleep(1000);

                // Procesar opción seleccionada
                switch (opcion)
                {
                    case 1: // Ingresar vehículo manualmente
                        Console.WriteLine("Ingrese la marca del vehículo:");
                        string marca_Vehi = Console.ReadLine();

                        Console.WriteLine("Ingrese el color del vehículo:");
                        string color_Vehi = Console.ReadLine();

                        // Validar formato de placa
                        bool placaValida = false;
                        while (!placaValida)
                        {
                            Console.Write("Ingrese la placa (6 caracteres, en mayúsculas): ");
                            placa_Vehi = Console.ReadLine();
                            if (placa_Vehi.Length == 6 && placa_Vehi == placa_Vehi.ToUpper())
                                placaValida = true;
                            else
                                Console.WriteLine("Placa inválida.");
                        }

                        // Validar tipo de vehículo
                        string tipo_Vehi = "";
                        bool tipoValido = false;
                        while (!tipoValido)
                        {
                            Console.Write("Ingrese el tipo del vehículo (moto, sedan, SUV): ");
                            tipo_Vehi = Console.ReadLine().ToLower();
                            if (tipo_Vehi == "moto" || tipo_Vehi == "sedan" || tipo_Vehi == "suv")
                                tipoValido = true;
                            else
                                Console.WriteLine("Tipo inválido.");
                        }

                        // Validar hora de entrada
                        int hora_Entrada;
                        while (true)
                        {
                            Console.Write("Ingrese la hora de entrada (6 a 20): ");
                            if (int.TryParse(Console.ReadLine(), out hora_Entrada) && hora_Entrada >= 6 && hora_Entrada <= 20)
                                break;
                            Console.WriteLine("Hora inválida.");
                        }

                        // Mostrar mapa de estacionamiento disponible
                        MostrarMapaEstacionamiento(matriz_Estacionamiento, tipo_Vehi);

                        // Seleccionar espacio de estacionamiento
                        bool codigoValido = false;
                        int pisoSeleccionado = 0, espacioSeleccionado = 0;

                        while (!codigoValido)
                        {
                            Console.Write("Ingrese código de parqueo (piso-columna): ");
                            codigo_Parqueo = Console.ReadLine();
                            var partes = codigo_Parqueo.Split('-');
                            if (partes.Length == 2 && int.TryParse(partes[0], out pisoSeleccionado) && int.TryParse(partes[1], out espacioSeleccionado))
                            {
                                pisoSeleccionado--; espacioSeleccionado--;
                                if (pisoSeleccionado >= 0 && pisoSeleccionado < cant_Pisos && espacioSeleccionado >= 0 && espacioSeleccionado < cant_Estacionamientos)
                                {
                                    string actual = matriz_Estacionamiento[pisoSeleccionado, espacioSeleccionado];
                                    if (actual == tipo_Vehi)
                                    {
                                        matriz_Estacionamiento[pisoSeleccionado, espacioSeleccionado] = placa_Vehi;
                                        codigoValido = true;
                                        Console.WriteLine("Vehículo estacionado con éxito.");
                                    }
                                    else if (actual != "moto" && actual != "suv" && actual != "sedan")
                                    {
                                        Console.WriteLine("Espacio ya ocupado.");
                                    }
                                    else
                                    {
                                        Console.WriteLine($"Espacio reservado para {actual}.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Código fuera de rango.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Formato inválido.");
                            }
                        }
                        break;

                    case 2: // Ingresar lote de vehículos (aleatorios)
                        Random rndGeneral = new Random();
                        int cantidadVehiculos = rndGeneral.Next(1, 8); // De 1 a 7 vehículos

                        for (int v = 0; v < cantidadVehiculos; v++)
                        {
                            string[] marcas = { "Honda", "Mazda", "Hyundai", "Toyota", "Suzuki" };
                            string[] colores = { "Rojo", "Azul", "Negro", "Gris", "Blanco" };
                            string[] tipos = { "moto", "sedan", "suv" };

                            // Generar datos aleatorios para el vehículo
                            string marca = marcas[rndGeneral.Next(marcas.Length)];
                            string color = colores[rndGeneral.Next(colores.Length)];
                            string tipo = tipos[rndGeneral.Next(tipos.Length)];

                            // Generar placa aleatoria
                            string letras = "", num = "";
                            for (int i = 0; i < 3; i++) letras += (char)rndGeneral.Next('A', 'Z' + 1);
                            for (int i = 0; i < 3; i++) num += rndGeneral.Next(0, 10).ToString();

                            string placa = letras + num;
                            int horaEntrada = rndGeneral.Next(6, 20);

                            // Mostrar información del vehículo generado
                            Console.WriteLine($"\nVehículo #{v + 1}");
                            Console.WriteLine("Marca: " + marca);
                            Console.WriteLine("Color: " + color);
                            Console.WriteLine("Placa: " + placa);
                            Console.WriteLine("Hora de entrada: " + horaEntrada);

                            // Mostrar mapa de estacionamiento disponible
                            MostrarMapaEstacionamiento(matriz_Estacionamiento, tipo);

                            // Buscar espacios disponibles para el tipo de vehículo
                            List<(int, int)> disponibles = new();
                            for (int i = 0; i < cant_Pisos; i++)
                            {
                                for (int j = 0; j < cant_Estacionamientos; j++)
                                {
                                    if (matriz_Estacionamiento[i, j].ToLower() == tipo.ToLower())
                                        disponibles.Add((i, j));
                                }
                            }

                            if (disponibles.Count == 0)
                            {
                                Console.WriteLine("No hay espacios disponibles para este tipo de vehículo.");
                            }
                            else
                            {
                                // Estacionar vehículo en espacio aleatorio disponible
                                var (fila, col) = disponibles[rndGeneral.Next(disponibles.Count)];
                                matriz_Estacionamiento[fila, col] = placa;
                                Console.WriteLine($"Vehículo estacionado en piso {fila + 1}, espacio {col + 1}.");
                            }
                        }
                        break;

                    case 3: // Buscar vehículo por placa
                        Console.WriteLine("Ingrese la placa del vehículo a buscar:");
                        string placaBuscar = Console.ReadLine();
                        bool encontrado = false;
                        for (int i = 0; i < cant_Pisos; i++)
                        {
                            for (int j = 0; j < cant_Estacionamientos; j++)
                            {
                                if (matriz_Estacionamiento[i, j] == placaBuscar)
                                {
                                    Console.WriteLine($"Vehículo encontrado en piso {i + 1}, espacio {j + 1}.");
                                    encontrado = true;
                                    break;
                                }
                            }
                            if (encontrado) break;
                        }
                        if (!encontrado) Console.WriteLine("Vehículo no encontrado.");
                        break;

                    case 4: // Retirar vehículo
                        Console.Write("Ingrese en que piso se encuentra el vehiculo (1 - {0}): ", cant_Pisos);
                        int pisoRetiro = int.Parse(Console.ReadLine());

                        Console.Write("Ingrese en que espacio se encuentra el vehiculo(1 - {0}): ", cant_Estacionamientos);
                        int espacioRetiro = int.Parse(Console.ReadLine());

                        int filaR = pisoRetiro - 1;
                        int colR = espacioRetiro - 1;

                        string contenidoEspacio = matriz_Estacionamiento[filaR, colR];

                        // Verificar si el espacio está ocupado
                        if (contenidoEspacio == "moto" || contenidoEspacio == "sedan" || contenidoEspacio == "suv")
                        {
                            Console.WriteLine("Ese espacio está vacío.");
                        }
                        else
                        {
                            Console.WriteLine($"Vehículo con placa '{contenidoEspacio}' retirado del piso {pisoRetiro}, espacio {espacioRetiro}.");
                        }

                        // Proceso de pago
                        string pagar = "";
                        int tarifa;

                        Console.WriteLine("Con que desea pagar? (Tarjeta/Efectivo)");
                        pagar = Console.ReadLine();

                        if (pagar == "Tarjeta" || pagar == "tarjeta" || pagar == "TARJETA")
                        {
                            Console.WriteLine("Pago realizado con exito");
                        }
                        else
                        {
                            // Calcular tarifa según tiempo aleatorio de estadía
                            int tiempo_Estadia = new Random().Next(0, 24);

                            if (tiempo_Estadia < 2)
                            {
                                tarifa = 0;
                            }
                            else if (tiempo_Estadia < 4)
                            {
                                tarifa = 15;
                            }
                            else if (tiempo_Estadia < 7)
                            {
                                tarifa = 45;
                            }
                            else if (tiempo_Estadia < 12)
                            {
                                tarifa = 60;
                            }
                            else
                            {
                                tarifa = 150;
                            }

                            // Proceso de pago en efectivo
                            int billetes100;
                            int billetes50;
                            int billetes20;
                            int billetes10;
                            int billetes5;
                            do
                            {
                                monto_Valido = false;
                                
                                int monto = 0;
                                if (tarifa > 0)
                                {
                                    Console.WriteLine("Su tarifa es de: " + tarifa + " Q");
                                    Console.WriteLine("Ingrese monto que utilizará para realizar el pago:");
                                    monto = Convert.ToInt32(Console.ReadLine());
                                }
                                else
                                {
                                    Console.WriteLine("Gracias por su visita");
                                }

                                if (monto < tarifa)
                                {
                                    Console.WriteLine("El monto ingresado no es suficiente, vuelva a ingresarlo");
                                }
                                else
                                {
                                    monto_Valido = true;

                                    // Calcular vuelto y desglosar en billetes
                                    vuelto = monto - tarifa;

                                    billetes100 = vuelto / 100;
                                    vuelto = vuelto % 100;

                                    billetes50 = vuelto / 50;
                                    vuelto = vuelto % 50;

                                    billetes20 = vuelto / 20;
                                    vuelto = vuelto % 20;

                                    billetes10 = vuelto / 10;
                                    vuelto = vuelto % 10;

                                    billetes5 = vuelto / 5;
                                    vuelto = vuelto % 5;

                                    // Mostrar desglose del vuelto
                                    if (billetes100 > 0)
                                    {
                                        Console.WriteLine("Q100 x" + billetes100);
                                    }
                                    if (billetes50 > 0)
                                    {
                                        Console.WriteLine("Q50 x" + billetes50);
                                    }
                                    if (billetes20 > 0)
                                    {
                                        Console.WriteLine("Q20 x" + billetes20);
                                    }
                                    if (billetes10 > 0)
                                    {
                                        Console.WriteLine("Q10 x" + billetes10);
                                    }
                                    if (billetes5 > 0)
                                    {
                                        Console.WriteLine("Q5 x" + billetes5);
                                    }
                                }
                            } while (monto_Valido = false);
                        }
                        break;

                    case 5: // Salir del programa
                        Console.WriteLine("¿Está seguro que desea salir? (S/N):");
                        string salir = Console.ReadLine();
                        if (salir.ToLower() == "s") respuesta = true;
                        break;
                }
            } while (opcion < 1 || opcion > 5);
        } while (!respuesta);
    }

    // Método para mostrar el mapa de estacionamiento disponible
    static void MostrarMapaEstacionamiento(string[,] matriz, string tipoBuscado)
    {
        Console.WriteLine($"\nMAPA DE ESTACIONAMIENTO DISPONIBLE ({tipoBuscado}):");
        for (int i = 0; i < matriz.GetLength(0); i++)
        {
            for (int j = 0; j < matriz.GetLength(1); j++)
            {
                if (matriz[i, j] == tipoBuscado.ToLower())
                    Console.Write($"{i + 1}-{j + 1}\t");
                else
                    Console.Write("X\t");
            }
            Console.WriteLine();
        }
    }
}