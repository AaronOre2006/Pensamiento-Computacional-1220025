﻿// See https://aka.ms/new-console-template for more information

string[] estudiantes = ["Juan", "Pedro", "Luisa", "Adriana", "Sofia"];
int[] notas = [88, 75, 96, 77, 59];


for (int i = 0; i < estudiantes.Length; i++)
{
    Console.WriteLine( estudiantes[i] + "-" + notas[i]);
}


int promedio = (88+75+96+77+59)/5;

Console.WriteLine("El promedio es:" + promedio);