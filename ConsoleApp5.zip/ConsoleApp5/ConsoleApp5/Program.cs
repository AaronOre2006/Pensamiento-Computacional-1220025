﻿


Console.WriteLine("\nElige una acción:");
                Console.WriteLine("1. Convertir de celsisus a fahrenheit");
                Console.WriteLine("2. Convertir de fahrenheit a celsius");
                Console.WriteLine("3. Informacion del Programador");
                Console.WriteLine("4. Salir");

               
                string opcion = Console.ReadLine();

               

                switch (opcion)
                {
                    case "1":
               double fahrenheit = celsiusfahrenheit();
                    Console.WriteLine($"La conversión es: {fahrenheit} °F");
                    break;

                    case "2":
                         double celsius = fahrenheitcelsius();
                    Console.WriteLine($"La conversión es: {celsius} °C");
                    break;

                    case "3":
                       Datos ();
                       break;

                    case "4":
                       
                    Adios();
                    break;

                    default:
                        Console.WriteLine("¡Error! Opción no válida");
                        break;
                }






static double celsiusfahrenheit()
{
Console.WriteLine("Ingrese el numero a convertir");
double C = Convert.ToDouble(Console.ReadLine());

return (C * 9/5) + 32;

}




static double fahrenheitcelsius()
{
    Console.WriteLine("Ingrese el numero a convertir");
double F = Convert.ToDouble(Console.ReadLine());

return (F-32) * 5/9;
}


void Datos ()
{
Console.WriteLine("Mi nombre es Aaron Moises Orellana Aguirre");
Console.WriteLine("Nací el 18 de octubre de 2006");

}

void Adios ()
{
Console.WriteLine("Que tenga un buen dia!");


}