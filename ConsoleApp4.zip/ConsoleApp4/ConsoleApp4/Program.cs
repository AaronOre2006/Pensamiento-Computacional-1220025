﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("Ingrese un texto:");
string texto = Console.ReadLine();

// Contar palabras (considerando que están separadas por espacios)
int contadorespacios = 0;

foreach (char c in texto)
{
    if (c == ' ')
        contadorespacios++;
}


// Capitalizar cada palabra
string[] palabras = texto.Split(' ');
string textoFinal = "";

foreach (string palabra in palabras)
{
    if (palabra.Length > 0)
    {
        textoFinal += char.ToUpper(palabra[0]) + palabra.Substring(1).ToLower() + " ";
    }
}

Console.WriteLine("\nTexto con palabras capitalizadas:");
Console.WriteLine(textoFinal.Trim());
Console.WriteLine("La cantidad de palabras: " + contadorespacios);
