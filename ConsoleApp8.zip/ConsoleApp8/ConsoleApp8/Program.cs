﻿// See https://aka.ms/new-console-template for more information


using System.Runtime.CompilerServices;
 

 
cilindro cilindro1 = new(4, 5);

cilindro1.MostrarInfo();

class cilindro{
    private int Radio;
    private int Altura;
    

 double volumen;
    public cilindro(int radio, int altura)
    {
        Radio = radio;
        Altura = altura;
        
        volumen = 3.1416*radio*altura;
    }


    public void MostrarInfo()
    {
        Console.WriteLine($"El radio es de: {Radio}");
        Console.WriteLine($"La altura es de: {Altura}");
        Console.WriteLine("El volumen es de: " + volumen);
      
        
    }
}


