﻿// See https://aka.ms/new-console-template for more information

using System.Timers;

Random generador = new Random();
int numeroaleatorio = generador.Next(0,51);


Console.WriteLine("Intente adivinar el numero");
int numero = Convert.ToInt32(Console.ReadLine());


  while (numeroaleatorio != numero)
        {
            if (numeroaleatorio > numero)
            {
                Console.WriteLine("El número aleatorio es mayor al número escogido, intente de nuevo.");
                }
            else
            {
                Console.WriteLine("El número aleatorio es menor al número escogido, intente de nuevo.");
 }
            numero = Convert.ToInt32(Console.ReadLine()); // Leer otro número
        

        if (numeroaleatorio == numero)
            {
                Console.WriteLine("¡Has adivinado!");
        
                break;
    }

}


