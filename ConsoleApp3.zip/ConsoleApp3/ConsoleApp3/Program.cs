﻿// See https://aka.ms/new-console-template for more information

/*
int numero;
do {
Console.WriteLine("Ingrese un numero positivo");
numero = Convert.ToInt32(Console.ReadLine());

if (numero<=0){

    Console.WriteLine("Numero incorrecto. Ingrese de nuevo");
}
else{
    Console.WriteLine("Numero correcto");
}
} while (numero<=0);



int edad;
do {
Console.WriteLine("Ingrese su edad");
edad = Convert.ToInt32(Console.ReadLine());

if (edad < 1 || edad > 100){

    Console.WriteLine("La edad no es valida. Ingrese de nuevo");
}
else{
    Console.WriteLine("Edad valida");
}
} while (edad < 1 || edad > 100);

*/



int numero;


do {
Console.WriteLine("Ingrese un numero mayor a 0");
numero = Convert.ToInt32(Console.ReadLine());

if (numero<=0){

    Console.WriteLine("Numero incorrecto. Ingrese de nuevo");
}

} while (numero<=0);

Console.WriteLine("Número correcto. Aquí está su tabla de multiplicar:");
int multiplicar = 1;

while (multiplicar<=10){

 Console.WriteLine(numero + " x " + multiplicar + " = " + (numero * multiplicar));
    multiplicar++;
        }
    



